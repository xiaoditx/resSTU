# 热键注册帮助

微软键代码查询：[Virtual-Key 代码](https://learn.microsoft.com/zh-cn/windows/win32/inputdev/virtual-key-codes)

键代码查询工具：本地路径`./tools/XD开发工具-T1`，仅支持10进制查询