#pragma once
#include<windows.h>
#include<cstdio>

extern void y_print(const char* s, int color);
extern bool hotkey();